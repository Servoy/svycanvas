/**
 * Refreshes the slider
 */
function refresh() {
}
